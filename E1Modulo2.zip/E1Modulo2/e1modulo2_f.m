% Adapted from https://www.ensta-bretagne.fr/jaulin/

function  xdot  = f(x,u)
% state x = (x(1),x(2), x(3))
% control u 

syms l1 l2 

x1 = x(1);
x2 = x(2);

u1 = u(1);
u2 = u(2);

xdot=[u1;u2];
end

