 %Adapted from https://www.ensta-bretagne.fr/jaulin/


init;

%For this system, the state is x =(x,hatx)

x = [0;pi/2]; % Initial state
u = [0;0];
y = [0;0];

dt=0.01;

l1 = 1;
l2 = 1;

c = [1;1];
r = 1/2;

frame_counter=0;

t=0;
 

for t=0:dt:25
    w = c + r*[cos(t);sin(t)] %Se aplica un error/input de 1.
    dw = r*[-sin(t);cos(t)]
    y = [l1*cos(x(1)) + l2*cos(x(1)+x(2)); l2*sin(x(1)) + l2*sin(x(1) + x(2))]
    v = (w - y) + dw

    invA = [cos(x(1) + x(2))/(l1*sin(x(2))), sin(x(1) + x(2))/(l1*sin(x(2)));
       -(l2*cos(x(1) + x(2)) + l1*cos(x(1)))/(l1*l2*sin(x(2))), -(l2*sin(x(1) + x(2)) + l1*sin(x(1)))/(l1*l2*sin(x(2)))]

    u = invA*v; %Esto es la funcion de u.

    x=x+e1modulo2_f(x,u)*dt % Euler
    %x=x+dt*(0.25*e_6p4_f(x,u)+0.75*(e_6p4_f(x+dt*(2/3)*e_6p4_f(x,u),u))); % Runge-Kutta
    
    frame_counter =frame_counter+1;
    
    % Frame sampling
    if frame_counter == 1 %Para separar puntos y demas
       %graph_draw(t,x,w,u); 
       arm_draw(x)
       pause(0.000001)
       frame_counter =0;
    end
end


