% Adapted from https://www.ensta-bretagne.fr/jaulin/


function e_5p11_draw(t,x,u)

  %plot(x(1),x(2),'r--.')

  plot(t,x(1),'k--.',t,x(2),'r--.',t,x(3),'b--.', t,u,'g--.')
  
end