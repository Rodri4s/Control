% Adapted from https://www.ensta-bretagne.fr/jaulin/

function  xdot  = f(x,w)
% state x = (x(1),x(2), x(3))
% control u 

x1 = x(1);
x2 = x(2);
z = x(3);

a0 = 2.5;
a1 = 2.5;

alpha0 = 3 - a0;
alpha1 = 3 - a1;
alpha_1 = 1;

B = -(alpha0 + a0)*x1 -(alpha1 + a1)*x2 + alpha_1*z + alpha0*w;

xdot=[x2; B; -x1 + w];
end

