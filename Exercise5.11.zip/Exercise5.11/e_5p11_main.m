 %Adapted from https://www.ensta-bretagne.fr/jaulin/

init;

%For this system, the state is x =(x,hatx)

x = [0;0;0]; % Initial state

dt=0.01;

frame_counter=0;

a0 = 2;
a1 = 2;

alpha0 = 3 - a0;
alpha1 = 3 - a1;
alpha_1 = 1;


t=0;

%e_5p11_draw(t,x,u); 

for t=0:dt:10
    y = x(1);
    w = 1; %Se aplica un error/input de 1.
    u = alpha_1*x(3) + alpha0*w - alpha0*x(1) - alpha1*x(2); %Esto es la funcion de u.

    x=x+e_5p11_f(x,w)*dt % Euler
    %x=x+dt*(0.25*e_5p11_f(x,u)+0.75*(e_5p11_f(x+dt*(2/3)*e_5p11_f(x,u),u))); % Runge-Kutta



    pause(dt);
    
    frame_counter =frame_counter+1;
    
    % Frame sampling
    if frame_counter == 15
       e_5p11_draw(t,x,u); 
       frame_counter =0;
    end
end


