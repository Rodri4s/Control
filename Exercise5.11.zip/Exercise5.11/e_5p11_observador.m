% Adapted from https://www.ensta-bretagne.fr/jaulin/

function  e_5p11_observador  = f(hatx,w,y)

e_5p11_observador = -5*hatx + w + y;
end

