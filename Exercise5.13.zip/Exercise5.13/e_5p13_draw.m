% Adapted from https://www.ensta-bretagne.fr/jaulin/


function e_5p13_draw(t,x)

  %plot(x(1),x(2),'r--.')

  plot(t,x(1),'b--.',t,x(2),'g--.',t,x(3),'r--.')
  
end