% Adapted from https://www.ensta-bretagne.fr/jaulin/

function  xdot  = f(x,u,w)
% state x = (x(1),x(2), x(3))
% control u 

x1 = x(1);
x2 = x(2);
x3 = x(3);

xdot=[x1 + x2; 2*x2 + u; -x1 + w];
end

