 %Adapted from https://www.ensta-bretagne.fr/jaulin/

init;

%For this system, the state is x =(x,hatx)

x= [0,0,0]; % Initial state

dt=0.01;

frame_counter=0;

alpha = 1;
k = [7 6];

t=0;

e_5p13_draw(t,x); 

for t=0:dt:10
    y = x(1);
    w = 1; %Se aplica un error/input de 1.
    u = -k(1)*x(1) -k(2)*x(2) + alpha*x(3); %Esto es la funcion de u.

    x=x+e_5p13_f(x,u,w)*dt % Euler
    %x=x+dt*(0.25*e_5p13_f(x,u)+0.75*(e_5p13_f(x+dt*(2/3)*e_5p13_f(x,u),u))); % Runge-Kutta



    pause(dt);
    
    frame_counter =frame_counter+1;
    
    % Frame sampling
    if frame_counter == 15
       e_5p13_draw(t,x); 
       frame_counter =0;
    end
end


