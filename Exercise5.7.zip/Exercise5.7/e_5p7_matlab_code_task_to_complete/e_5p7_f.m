% Adapted from https://www.ensta-bretagne.fr/jaulin/

function  xdot  = f(x,u)
% state x = (x(1),x(2))
% control u 

x1= x(1);
x2= x(2);

xdot=[x1 + 2*x2 + u; 3*x1 + 4*x2 + 2*u];
end

