% Adapted from https://www.ensta-bretagne.fr/jaulin/


function e_6p3_draw(t,x,y,hatx)

  %plot(x(1),x(2),'r--.')

  plot(t,x,'r--.',t,y,'b--.',t,hatx,'k--.')
  
end