 %Adapted from https://www.ensta-bretagne.fr/jaulin/

init;

%For this system, the state is x =(x,hatx)

x = 2; % Initial state
hatx = 0;

dt=0.01;

frame_counter=0;

x_eq = 2;
y_eq = 6;
u_eq = -8;
w_eq = 6;

K = 9;
H = 1/3;

t=0;

%e_6p3_draw(t,x,u); 

for t=0:dt:5
    w = 6; %Se aplica un error/input de 1.
    y = 3*x;
    u = -8 - 9*hatx + (1/3)*(w-6); %Esto es la funcion de u.

    x=x+e_6p3_f(x,u)*dt % Euler
    %x=x+dt*(0.25*e_6p3_f(x,u)+0.75*(e_6p3_f(x+dt*(2/3)*e_6p3_f(x,u),u))); % Runge-Kutta


    hatx=x+e_6p3_observador(hatx,w,y)*dt % Euler
    %x=x+dt*(0.25*e_6p3_f(x,u)+0.75*(e_6p3_f(x+dt*(2/3)*e_6p3_f(x,u),u))); % Runge-Kutta

    pause(dt);
    
    frame_counter =frame_counter+1;
    
    % Frame sampling
    if frame_counter == 15
       e_6p3_draw(t,x,y,hatx); 
       frame_counter =0;
    end
end


