% Adapted from https://www.ensta-bretagne.fr/jaulin/

function  e_6p3_observador  = f(hatx,w,y)

e_6p3_observador = -10*hatx + (1/3)*(w-6) + 3*(y-6);
end

