% Adapted from https://www.ensta-bretagne.fr/jaulin/


function e_6p4_draw(t,x,u)

  %plot(x(1),x(2),'r--.')

  plot(t,x(1),'k--.',t,x(2),'r--.',t,u,'g--.')
  
end