% Adapted from https://www.ensta-bretagne.fr/jaulin/

function  xdot  = f(x,u)
% state x = (x(1),x(2), x(3))
% control u 

x1 = x(1);
x2 = x(2);

xdot=[x(2); u-sin(x(1))-x(2)];
end

