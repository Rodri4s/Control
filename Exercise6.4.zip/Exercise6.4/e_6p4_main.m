 %Adapted from https://www.ensta-bretagne.fr/jaulin/

init;

%For this system, the state is x =(x,hatx)

%x = [0;0]; % Initial state
x = [pi-15/180*pi; -5/180*pi]
dt=0.01;

frame_counter=0;

t=0;

%e_6p4_draw(t,x,u); 

for t=0:dt:10
    %w = 1; %Se aplica un error/input de 1.
    u = -2*x(1) + 2*pi -x(2); %Esto es la funcion de u.

    x=x+e_6p4_f(x,u)*dt % Euler
    %x=x+dt*(0.25*e_6p4_f(x,u)+0.75*(e_6p4_f(x+dt*(2/3)*e_6p4_f(x,u),u))); % Runge-Kutta



    pause(dt);
    
    frame_counter =frame_counter+1;
    
    % Frame sampling
    if frame_counter == 30 %Para separar puntos y demas
       %e_6p4_draw(t,x,u); 
       e_6p4_pendulum_draw(x)
       frame_counter =0;
    end
end


