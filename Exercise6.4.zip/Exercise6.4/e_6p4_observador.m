% Adapted from https://www.ensta-bretagne.fr/jaulin/

function  e_6p4_observador  = f(hatx,w,y)

e_6p4_observador = -5*hatx + w + y;
end

