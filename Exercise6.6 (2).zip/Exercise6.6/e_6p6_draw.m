% Adapted from https://www.ensta-bretagne.fr/jaulin/


function  e_6p6_draw(t,x,w)

  %plot(x(1),x(2),'r--.')

  plot(t,x(1),'k--.',t,x(2),'r--.',t,w,'b--.')
  
end