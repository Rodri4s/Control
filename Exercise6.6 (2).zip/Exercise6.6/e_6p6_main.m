 %Adapted from https://www.ensta-bretagne.fr/jaulin/

init;

%Definicion de variables
mc = 5;
l = 4;
mr = 1;
g = 9.81;

u_ = 0;             %Pendulo en equilibrio -------------- para la practica es mg;0
x_ = [0;0;0;0];         %Posicion en equilibrio
w_ = 0;                 %w_ = E*x_

%Definicion de Matrices
A = [0, 0, 1, 0;
     0, 0, 0, 1;
     0, (g*mr)/mc, 0, 0;
     0, (g*(mc + mr))/(mc*l), 0, 0];

B = [0; 0; 1/mc; 1/(l*mc)];


E = [1,0,0,0];                      %La componente que se quiere controlar -------Para pra2 es [1,1,0,0]
p = [-2,-2.1,-2.2,-2.3];            %Los polos
K = place(A,B,p);                   %Matriz para luego calcular u
H = -inv(E*inv(A-B*K)*B);           %Valor de precompensador

x = [0;0;0;0]; %Initial state
dt=0.01;

frame_counter=0;

t=0;


for t=0:dt:60
    w = square(0.5*t); %Se aplica un error/input de 1.
    y = x(1);
    %u = -2*x(1) + 2*pi -x(2); %Esto es la funcion de u.
    %u =  -K*(x) + H*(w)

    %Segunda posibilidad para representar u
    xdes = [w;0;0;0];
    u = u_ -K*(x-xdes)

    x=x+ e_6p6_f(x,u)*dt % Euler
    %x=x+dt*(0.25* e_6p6_f(x,u)+0.75*( e_6p6_f(x+dt*(2/3)* e_6p6_f(x,u),u))); % Runge-Kutta

    pause(dt);
    
    frame_counter =frame_counter+1;
    
    % Frame sampling
    if frame_counter == 5 %Para separar puntos y demas
        e_6p6_draw(t,x,w); 
        %e_6p6_pendulum_draw(x)
       frame_counter =0;
    end
end


