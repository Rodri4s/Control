function  e_6p6_pendulum_draw(x)
    %clc()
    hold on
    axis square
    axis([-1,1,-1,1])

    theta = 50;
    x = 1;
    y = 0;

    pendulo = [0,0;0,1;1,1];

    matriz_rot = [cos(theta), -sin(theta), 0; ...
                  sin(theta), cos(theta), 0; ...
                  0,0,1];

    matriz_tras = [1,0,x;
                   0,1,y;
                   0,0,1];

    aplica = matriz_rot*matriz_tras;

    resultado = aplica*pendulo

    plot(resultado(1,:), resultado(2,:), "black","LineWidth",1)
    pause(100)
end