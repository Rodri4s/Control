 %Adapted from https://www.ensta-bretagne.fr/jaulin/

init;

%Definicion de variables
mc = 5;
l = 4;
mr = 1;
g = 9.81;

%Definicion de Matrices
A = [0,0,1,0; 0,0,0,1; 0,(g*mr)/mc,0,0; 0,(g*mc*(mc+mr))/l,0,0];
B = [0; 0; l/mc; l/(l*mc)];
C = [1,0,0,0];
D = [1,0,0,0];

x = [0;0;0;0]; %Initial state
xr = [0;0;0;0]; %Initial state observer
dt=0.01;

frame_counter=0;

t=0;

% e_6p6_draw(t,x,u); 

for t=0:dt:10
    w = square(0.5*t); %Se aplica un error/input de 1.
    y = x(1);
    u = -2*x(1) + 2*pi -x(2); %Esto es la funcion de u.

    x=x+ e_6p6_f(x,u)*dt % Euler
    %x=x+dt*(0.25* e_6p6_f(x,u)+0.75*( e_6p6_f(x+dt*(2/3)* e_6p6_f(x,u),u))); % Runge-Kutta

%Agregar observador
%Agregar simulador de pendulo invertido


    pause(dt);
    
    frame_counter =frame_counter+1;
    
    % Frame sampling
    if frame_counter == 15 %Para separar puntos y demas
        e_6p6_draw(t,x,u); 
        %e_6p6_pendulum_draw(x)
       frame_counter =0;
    end
end


