%% Calculo de puntos operativos. Para que sirven? Son valores de equilibrio? Si U es cero, es punto de equilibrio.
clear all
close all
clc

syms  x2 x3 x4 u

mc = 5;
l = 4;
mr = 1;
g = 9.81;

x3p = -mr*sin(x2)*(l*(x4)^2-g*cos(x2)) + u;
x4p = sin(x2)*(mc+mr)*g-mr*l*(x4)^2*cos(x2) + u*cos(x2);

%x3p = (-sin(x2)*(4*(x4)^2-9.8*cos(x2)))/(5+(sin(x2))^2) + u/(5+(sin(x2))^2);
%x4p = (sin(x2)*(6*9.8)-4*(x4)^2*cos(x2))/(4*(5+(sin(x2))^2)) + (u*cos(x2))/4*(5+(sin(x2))^2);

dx = [x3;x4;x3p;x4p];

S = solve(dx(1)==0, dx(2)==0,dx(3)==0,dx(4)==0,x2,x3,x4,u,'Real',true);

Su = S.u
S2 = S.x2
S3 = S.x3
S4 = S.x4

%% Modelo linealizado. Se obtienen las derivadas parciales.
clear all
close all
clc

syms  l mc mr g x1 x2 x3 x4 u

%syms  x1 x2 x3 x4 u
%mr = 1; mc = 5; l = 4; g = 9.81;

f1 = x3;
f2 = x4;
f3 = (-mr*sin(x2)*(l*(x4)^2-g*cos(x2)))/(mc + mr*sin(x2)^2) + u/(mc + mr*sin(x2)^2);
f4 = (sin(x2)*((mc+mr)*g-mr*l*(x4)^2*cos(x2)))/l*(mc + mr*sin(x2)^2) + (u*cos(x2))/(l*mc + mr*sin(x2)^2);


A = jacobian([f1,f2,f3,f4],[x1,x2,x3,x4])
B = jacobian([f1,f2,f3,f4],u)

%% Se sustituyen los puntos de equilibrio
subs(A,[x1 x2 x3 x4], [0 0 0 0])
subs(B,[x1 x2 x3 x4], [0 0 0 0])
