function  e_6p6_pendulum_draw(x)
    %clc()
    hold on
    axis square
    axis([-1,1,-1,1])

plot([0,sin(x(1))], [0, -cos(x(1))], 'black', 'LineWidth',2)
end