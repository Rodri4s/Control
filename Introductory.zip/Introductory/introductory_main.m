 %Adapted from https://www.ensta-bretagne.fr/jaulin/

init;

%For this system, the state is x =(x,hatx)

x = [0;0]; % Initial state
%x = [pi-15/180*pi; -5/180*pi]
dt=0.01;

frame_counter=0;

t=0;

for t=0:dt:25
    w = sin(t); %Se aplica un error/input de 1.
    dw = cos(t);
    ddw = -sin(t);

    u = sin(x(1)) + (w-x(1)) + 2*(dw-x(2))+ddw; %Esto es la funcion de u.

    x=x+introductory_f(x,u)*dt % Euler
    %x=x+dt*(0.25*e_6p4_f(x,u)+0.75*(e_6p4_f(x+dt*(2/3)*e_6p4_f(x,u),u))); % Runge-Kutta

    pause(dt);
    
    frame_counter =frame_counter+1;
    
    % Frame sampling
    if frame_counter == 15 %Para separar puntos y demas
       introductory_draw(t,x,w,u); 
       %pendulum_draw(x)
       frame_counter =0;
    end
end


