% Adapted from https://www.ensta-bretagne.fr/jaulin/

function  xdot  = f(x,u)
% state x = (x(1),x(2), x(3))
% control u 

%Parametros
l_z1 = 1;
l_z2 = 1;
m1 = 1;
m2 = 1;
l1 = 1;
l2 = 1;
r1 = l1/2;
r2 = l2/2;

%Definicion de Variables
x1 = x(1);
x2 = x(2);
x3 = x(3);
x4 = x(4);
u1 = u(1);
u2 = u(2);

%Cambio de nombres
q1 = x1;
q2 = x2;
q1_d = x3;
q2_d = x4;

alpha = l_z1 + l_z2 + m1*(r1)^2 + m2*((l1)^2 + (r2)^2)
beta = m2*l1*r2;
delta = l_z2 + m2*(r2)^2;

B = [alpha + 2*beta*cos(q2), delta + beta*cos(q2);
    delta + beta*cos(q2), delta];

C = [-beta*sin(q2)*q2_d, -beta*sin(q2)*(q1_d + q2_d);
    beta*sin(q2)*q1_d, 0];

xp34 = -inv(B)*C*[x3; x4] + inv(B)*[u1; u2]

xdot=[x3; x4; xp34(1); xp34(2)];
end

