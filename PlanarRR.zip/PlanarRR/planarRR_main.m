 %Adapted from https://www.ensta-bretagne.fr/jaulin/


init;

%For this system, the state is x =(x,hatx)

% Initial state
x = [-pi/3;(2*pi)/3;0;0]; 
u = [0;0];
y = [0;0];

dt=0.01;

%Parametros
l_z1 = 1;
l_z2 = 1;
m1 = 1;
m2 = 1;
l1 = 1;
l2 = 1;
r1 = l1/2;
r2 = l2/2;



frame_counter=0;

t=0;
 

for t=0:dt:100
    y = [l1*cos(x(1)) + l2*cos(x(1) + x(2)); l1*sin(x(1)) + l2*sin(x(1) + x(2))];
    p = y;
    J = [-l2*sin(x(1) + x(2)) - l1*sin(x(1)), -l2*sin(x(1) + x(2));
        l2*cos(x(1) + x(2)) + l1*cos(x(1)), l2*cos(x(1) + x(2))];
    Kp = [20, 0;
          0, 40];
    Kd = [10, 0;
          0, 20];
    
    %Posicion deseada
    pd = [1;1];
    u = transpose(J)*Kp*(pd - p) - Kd*[x(3); x(4)]; %Esto es la funcion de u.

    x=x+planarRR_f(x,u)*dt % Euler
    %x=x+dt*(0.25*e_6p4_f(x,u)+0.75*(e_6p4_f(x+dt*(2/3)*e_6p4_f(x,u),u))); % Runge-Kutta
    
    frame_counter =frame_counter+1;
    
    % Frame sampling
    if frame_counter == 5 %Para separar puntos y demas
       %graph_draw(t,x,w,u); 
       arm_draw(x)
       pause(0.000001)
       frame_counter =0;
    end
end


