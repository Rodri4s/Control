function arm_draw(x)
    l1 = 1;
    l2 = 1;
    c = [1,1];
    r = 1/2;    


    %clf()
    hold on
    axis square
    axis([-1,2,-1,2])
    
    x1 = x(1);
    x2 = x(2);

    arm1 = [0, l1;
            0,0;
            1,1];

    arm2 = [0, l2;
            0,0;
            1,1];

    rota1 = [cos(x1), -sin(x1), 0;
            sin(x1), cos(x1), 0;
            0,0,1];

    rota2 = [cos(x2), -sin(x2), 0;
            sin(x2), cos(x2), 0;
            0,0,1];

    tras = [1,0,l1;
            0,1,0;
            0,0,1];

    result1 = rota1*arm1;
    result2 = rota1*tras*rota2*arm2;
    circle = nsidedpoly(1000,"Center", c, "Radius", r);


    plot(circle, "FaceColor", "w", "FaceAlpha",0)
    plot(result1(1,:),result1(2,:),"black", "LineWidth",1)
    plot(result2(1,:),result2(2,:),"blue", "LineWidth",1)

end