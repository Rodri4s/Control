% Adapted from https://www.ensta-bretagne.fr/jaulin/


function graph_draw(t,x,w,u)

  %plot(x(1),x(2),'r--.')

  plot(t,x(1),'k--.',t,w,'r--.',t,u,'g--.')
  
end