% Adapted from https://www.ensta-bretagne.fr/jaulin/


function  pra2_draw(t,x,u)

  %plot(x(1),x(2),'r--.')

  plot(t,x(1),'k--.',t,x(2),'r--.',t,x(2),'b--.',t,u,'g--.')
  
end