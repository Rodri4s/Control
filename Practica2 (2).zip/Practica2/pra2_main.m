 %Adapted from https://www.ensta-bretagne.fr/jaulin/

syms S F m g

init;

%% Definicion de variables
J = 10000;
m = 30000;
d = 5.5;
g = 9.81;

S = m*g;

%% Definicion de Matrices en equilibrio
A = [0,0,0,1,0,0;
     0,0,0,0,1,0;
     0,0,0,0,0,1;
     0,0,-S/m,0,0,0;
     0,0,0,0,0,0;
     0,0,0,0,0,0]

B = [0,0;
     0,0;
     0,0;
     0,0;
     1/m,0;
     0,(2*d)/J]

%C = [0,1,0,0,0,0];

%% Regulador KLH
%{
P = [0,0,0,0,0,0];   
x = -2;
dx = -1.7;
for i = 1:6
    P(i) = x;
    x = x + dx;
end
%}
P =[-2, -5.3, -6.2, -5.9, -5.4, -3.6]                         %Definicion de polos.

E = [1,0,0,0,0,0;           %Matriz de seleccion para estado deseado.
     0,1,0,0,0,0];
K = place(A,B,P)            
H = -inv(E*inv(A-B*K)*B)    %Precompensador


x = [1;5;0.0174533;-0.1;-0.2; 0.00174533];          %Initial state punto 6
%x = [0;5;0.0174533;-0.1;-0.2;0.00174533];           %Initial state punto 7
dt=0.01;

frame_counter=0;

t=0;

%% Variables de equilibrio
x_eq = [0;0;0;0;0;0;];
w_eq = [0;0];
u_eq = [m*g; 0];

%% Secuencia
for t=0:dt:10
    w = [0;2.4];
    %w = [10;5];
    u = -u_eq - K*x + H*w; %Esto es la funcion de u.

    x=x+ pra2_f(x,u)*dt % Euler
    %x=x+dt*(0.25* pra2_f(x,u)+0.75*( pra2_f(x+dt*(2/3)* pra2_f(x,u),u))); % Runge-Kutta


    pause(dt);
    
    frame_counter =frame_counter+1;
    
    % Frame sampling
    if frame_counter == 15 %Para separar puntos y demas
        %pra2_draw(t,x,u); 
        pra2_pendulum_draw(x)
       frame_counter =0;
    end
end
%}
