%% Calculo de puntos operativos.
clear all
close all
clc

syms  x3 x4 x5 x6 S F J m d g

%Representación de estado----------------------------------------------------
%{
J = 10000;
m = 30000;
d = 5.5;
g = 9.81;
%}

xp = x4;
yp = x5;
thetap = x6;
xpp = -S*(sin(x3)/m);
ypp = -g + S*(cos(x3)/m);
thetapp = F*(2*d/J);


dx=[xp;yp;thetap;xpp;ypp;thetapp];

Solution = solve(dx(1)==0, dx(2)==0,dx(3)==0,dx(4)==0, ...
    dx(5)==0,dx(6)==0,x3,x4,x5,x6,S,F,'Real',true);

Solution_S = Solution.S %Punto en equilibrio de S.
Solution_F = Solution.F
Solution_x3 = Solution.x3
Solution_x4 = Solution.x4
Solution_x5 = Solution.x5
Solution_x6 = Solution.x6
