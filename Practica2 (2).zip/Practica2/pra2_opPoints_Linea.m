%% Calculo de puntos de equilibrio.
%% Modelo linealizado. Se obtienen las derivadas parciales.---------------
clear all
close all
clc

syms  J m d g x1 x2 x3 x4 x5 x6 S F

%syms  x1 x2 x3 x4 x5 x6 S F
%J = 10000; m=30000; d=5.5; g = 9.81;

f1 = x4;
f2 = x5;
f3 = x6;
f4 = -S*(sin(x3)/m);
f5 = -g + S*(cos(x3)/m);
f6 = F*(2*d/J);
f7 = x2

A = jacobian([f1,f2,f3,f4,f5,f6],[x1,x2,x3,x4,x5,x6])
B = jacobian([f1,f2,f3,f4,f5,f6],[S,F])
C = jacobian([f7],[x1,x2,x3,x4,x5,x6])

%% Se sustituyen los puntos de equilibrio---------------------------------
subs(A,[x1,x2,x3,x4,x5,x6], [0 0 0 0 0 0])
subs(B,[x1,x2,x3,x4,x5,x6], [0 0 0 0 0 0])
subs(C,[x1,x2,x3,x4,x5,x6], [0 0 0 0 0 0])