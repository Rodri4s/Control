function  pra2_pendulum_draw(x)
clc()
    clf()
    hold on
    axis square
    axis([-6,6,-1,10])       
    
    %Variables de entrada
    x1 = x(1);
    %x1 = 0
    y1 = x(2);
    %y1 = 0
    theta = x(3);
    %theta = 0

    pendulo = [-4,-4,0,0,0,4,4;         %Dibujo de la barra
               1,0,0,-0.5,0,0,1;
               1,1,1,1,1,1,1];        

    matriz_rot = [cos(theta), -sin(theta), 0; ...
                  sin(theta), cos(theta), 0; ...
                  0,0,1];

    matriz_tras = [1,0,x1;
                   0,1,y1;
                   0,0,1];

    aplica = matriz_tras*matriz_rot;

    resultado = aplica*pendulo

    plot(resultado(1,:), resultado(2,:), "black","LineWidth",1)
end