% Adapted from https://www.ensta-bretagne.fr/jaulin/

function  xdot  = f(x,S,F)
% state x = (x(1),x(2), x(3))
% control u 

J = 10000;
m = 30000;
d = 5.5;
g = 9.81;


%Variables de estado-------------------------
x1 = x(1);
x2 = x(2);
x3 = x(3);
x4 = x(4);
x5 = x(5);
x6 = x(6);

%Espacio de estado---------------------------
xp = x4;
yp = x5;
thetap = x6;
xpp = -S*(sin(x3)/m);
ypp = -g + S*(cos(x3)/m);
thetapp = F*(2*d/J);


xdot=[xp;yp;thetap;xpp;ypp;thetapp];
end

