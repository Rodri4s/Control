%Template para obtener el polinomio caracteristico, para obtener el valor 
%de los polos.

syms S m

A = [0,0,0,1,0,0; 0,0,0,0,0,1; 0,0,0,0,0,1; 0,0,-S/m,0,0,0; 0,0,0,0,0,0; 0,0,0,0,0,0]; %Ingresar valor de la matriz A
C = [0,1,0,0,0,0];
P = simplify(det(s*eye(6)-A+C))